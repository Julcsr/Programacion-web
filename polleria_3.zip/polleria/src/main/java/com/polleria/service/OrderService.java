package com.polleria.service;

import com.polleria.entity.Order;

public interface OrderService  extends CrudService<Order, Long> {

}
