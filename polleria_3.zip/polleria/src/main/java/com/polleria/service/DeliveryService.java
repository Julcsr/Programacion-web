package com.polleria.service;

import com.polleria.entity.Delivery;

public interface DeliveryService extends CrudService<Delivery, Long> {

}
