package com.polleria.controller;


import java.util.List;


import org.aspectj.bridge.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.polleria.entity.Employee;
import com.polleria.entity.Office;
import com.polleria.entity.Position;
import com.polleria.service.EmployeeService;
import com.polleria.service.OfficeService;
import com.polleria.service.PositionService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private OfficeService officeService;
	
	@Autowired
	private PositionService positionService;
	
	@GetMapping
    public String showAllEmployee(Model model) {
        model.addAttribute("employees", employeeService.getAll());
        model.addAttribute("positions", positionService.getAll());
        model.addAttribute("offices", officeService.getAll());
        return "employees/list";
    }
	
	@GetMapping("/new")
    public String newEmployeeForm(Model model) {
        List<Office> offices = officeService.getAll();
        List<Position> positions = positionService.getAll();
        model.addAttribute("positions", positions);
        model.addAttribute("offices", offices);
        model.addAttribute("employee", new Employee());
        return "employees/new";
    }
	
	@PostMapping("/save")
    public String saveNewEmployee(Employee employee) {
        long id = employeeService.create(employee);
        return "redirect:/employees";
    }
	
	@GetMapping("/show/{id}")
    public String showOrder(@PathVariable("id") long id, Model model) {
        model.addAttribute("employees", employeeService.getOneById(id));
        return "employees/show";
    }
	
	@GetMapping("/delete/{id}")
    public String deleteEmployeeForm(@PathVariable("id") long id, Model model) {
		try {
			  employeeService.delete(id);
		        model.addAttribute("employees", employeeService.getAll());
		        return "employees/list";    
		} catch (Exception e) {
			 model.addAttribute("employees", employeeService.getAll());
			Message.INFO.equals("Error");
		}
	    return "employees/list";    
  }

	
	@GetMapping("/edit/{id}")
    public String editEmployeeForm(@PathVariable("id") long id, Model model) {
        Employee employee = employeeService.getOneById(id);
        List<Office> offices = officeService.getAll();
        List<Position> positions = positionService.getAll();
        model.addAttribute("position", positions);
        model.addAttribute("office", offices);
        model.addAttribute("employee", employee);
        return "employees/edit";
    }

	
	@PostMapping("/update/{id}")
    public String updateEmployee(@PathVariable("id") long id, Employee employee) {
		employeeService.update(id, employee);
        return "redirect:/employees";    
    }
	
}
