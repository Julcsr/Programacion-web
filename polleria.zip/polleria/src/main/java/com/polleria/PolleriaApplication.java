package com.polleria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolleriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolleriaApplication.class, args);
	}

}
