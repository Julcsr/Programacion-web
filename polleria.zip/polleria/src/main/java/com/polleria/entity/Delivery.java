package com.polleria.entity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "deliveries")
public class Delivery {
	private Long id;
	private String adress;
	@JoinColumn(name = "id_motorized")
	@ManyToOne
	private Employee motorized;
	@ManyToOne
	@JoinColumn(name = "id_call_receptionist")
	private Employee callReceptionist;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public Employee getMotorized() {
		return motorized;
	}

	public void setMotorized(Employee motorized) {
		this.motorized = motorized;
	}

	public Employee getCallReceptionist() {
		return callReceptionist;
	}

	public void setCallReceptionist(Employee callReceptionist) {
		this.callReceptionist = callReceptionist;
	}

}
