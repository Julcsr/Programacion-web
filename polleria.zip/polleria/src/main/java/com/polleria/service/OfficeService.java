package com.polleria.service;

import com.polleria.entity.Office;

public interface OfficeService extends CrudService<Office, Long>{

}
