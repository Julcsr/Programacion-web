package com.polleria.service;

import com.polleria.entity.Employee;

public interface EmployeeService extends CrudService<Employee, Long> {

}
