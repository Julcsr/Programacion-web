package com.polleria.service;

import com.polleria.entity.Position;

public interface PositionService extends CrudService<Position, Long> {

}
