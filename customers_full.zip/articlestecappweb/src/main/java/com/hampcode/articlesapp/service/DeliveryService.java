package com.hampcode.articlesapp.service;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.hampcode.articlesapp.model.Delivery;


public interface DeliveryService extends CrudService<Delivery, Long> {
	public List<Delivery> fechfindByid(Long id);
	Page<Delivery> findAll(Pageable pageable);
}
