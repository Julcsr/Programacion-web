package com.hampcode.model.entity;

public class Sucursal {
	Long idSucursal;
	int numTelefonoSucursal;
	String direccionSucursal;

	public Long getIdSucursal() {
		return idSucursal;
	}

	public void setIdSucursal(Long idSucursal) {
		this.idSucursal = idSucursal;
	}

	public int getNumTelefonoSucursal() {
		return numTelefonoSucursal;
	}

	public void setNumTelefonoSucursal(int numTelefonoSucursal) {
		this.numTelefonoSucursal = numTelefonoSucursal;
	}

	public String getDireccionSucursal() {
		return direccionSucursal;
	}

	public void setDireccionSucursal(String direccionSucursal) {
		this.direccionSucursal = direccionSucursal;
	}

}
