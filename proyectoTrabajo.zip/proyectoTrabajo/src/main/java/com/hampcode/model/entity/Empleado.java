package com.hampcode.model.entity;

public class Empleado {
	Long idEmpleado;
	String nombreEmpleado;
	CargoEmpleado cargoEmpleado;
	Sucursal sucursal;

	public Long getIdEmpleado() {
		return idEmpleado;
	}

	public void setIdEmpleado(Long idEmpleado) {
		this.idEmpleado = idEmpleado;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public CargoEmpleado getCargo_empleado() {
		return cargoEmpleado;
	}

	public void setCargo_empleado(CargoEmpleado cargo_empleado) {
		this.cargoEmpleado = cargo_empleado;
	}

	public Sucursal getSucursal() {
		return sucursal;
	}

	public void setSucursal(Sucursal sucursal) {
		this.sucursal = sucursal;
	}

}
