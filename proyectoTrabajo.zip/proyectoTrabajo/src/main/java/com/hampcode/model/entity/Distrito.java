package com.hampcode.model.entity;

public class Distrito {
	Long idDistrito;
	String nombreDistrito;
	Provincia provincia;

	public Long getIdDistrito() {
		return idDistrito;
	}

	public void setIdDistrito(Long idDistrito) {
		this.idDistrito = idDistrito;
	}

	public String getNombreDistrito() {
		return nombreDistrito;
	}

	public void setNombreDistrito(String nombreDistrito) {
		this.nombreDistrito = nombreDistrito;
	}

	public Provincia getIdProvincia() {
		return provincia;
	}

	public void setIdProvincia(Provincia idProvincia) {
		this.provincia = idProvincia;
	}

}
