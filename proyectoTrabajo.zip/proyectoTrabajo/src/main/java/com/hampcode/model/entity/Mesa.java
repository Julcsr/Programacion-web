package com.hampcode.model.entity;

public class Mesa {
	Long idMesa;
	int numAsientos;
	Sucursal sucursal;
	Local pLocal;

	public Long getIdMesa() {
		return idMesa;
	}

	public void setIdMesa(Long idMesa) {
		this.idMesa = idMesa;
	}

	public int getNumAsientos() {
		return numAsientos;
	}

	public void setNumAsientos(int numAsientos) {
		this.numAsientos = numAsientos;
	}

	public Sucursal getSucursal() {
		return sucursal;
	}

	public void setSucursal(Sucursal sucursal) {
		this.sucursal = sucursal;
	}

	public Local getpLocal() {
		return pLocal;
	}

	public void setpLocal(Local pLocal) {
		this.pLocal = pLocal;
	}

}
