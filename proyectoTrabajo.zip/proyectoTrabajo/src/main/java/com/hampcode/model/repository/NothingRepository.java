package com.hampcode.model.repository;

import java.io.Serializable;

import javax.inject.Named;

@Named
public class NothingRepository implements Serializable {

	
	private static final long serialVersionUID = 1L;

	
}
