package com.hampcode.model.entity;

public class TipoVivienda {
	Long idTipoVivienda;
	String nombreTipoVivienda;

	public Long getIdTipoVivienda() {
		return idTipoVivienda;
	}

	public void setIdTipoVivienda(Long idTipoVivienda) {
		this.idTipoVivienda = idTipoVivienda;
	}

	public String getNombreTipoVivienda() {
		return nombreTipoVivienda;
	}

	public void setNombreTipoVivienda(String nombreTipoVivienda) {
		this.nombreTipoVivienda = nombreTipoVivienda;
	}

}
