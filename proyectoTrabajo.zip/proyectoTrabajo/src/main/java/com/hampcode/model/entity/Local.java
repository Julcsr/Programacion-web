package com.hampcode.model.entity;

public class Local {
	Long idLocal;
	Empleado mozo;

	public Long getIdLocal() {
		return idLocal;
	}

	public void setIdLocal(Long idLocal) {
		this.idLocal = idLocal;
	}

	public Empleado getMozo() {
		return mozo;
	}

	public void setMozo(Empleado mozo) {
		this.mozo = mozo;
	}

}
