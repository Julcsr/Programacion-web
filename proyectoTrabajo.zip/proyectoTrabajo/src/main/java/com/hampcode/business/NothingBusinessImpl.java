package com.hampcode.business;

import java.io.Serializable;

import javax.inject.Named;

@Named
public class NothingBusinessImpl implements Serializable{


	private static final long serialVersionUID = 1L;

}
