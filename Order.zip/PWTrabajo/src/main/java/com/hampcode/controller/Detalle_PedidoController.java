package com.hampcode.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import com.hampcode.business.DescuentoBusiness;
import com.hampcode.business.Detalle_PedidoBusiness;
import com.hampcode.business.PedidoBusiness;
import com.hampcode.business.ProductoBusiness;
import com.hampcode.model.entity.Descuento;
import com.hampcode.model.entity.Detalle_Pedido;
import com.hampcode.model.entity.Pedido;
import com.hampcode.model.entity.Producto;
import com.hampcode.util.Message;
//Esta parte es lo que va a hacer el cajero
@Named
@SessionScoped
public class Detalle_PedidoController implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Detalle_PedidoBusiness detalle_pedidoBusiness;
	
	@Inject
	private PedidoBusiness pedidoBusiness;
	
	@Inject
	private ProductoBusiness productoBusiness;
	
	@Inject
	private DescuentoBusiness descuentoBusiness;
	
	private Detalle_Pedido detalle_pedido; //NuevoProducto
	private List<Detalle_Pedido> listaDetalle_Pedido;//ListaProductos
	private Optional<Detalle_Pedido> listaDetalle_Pedido_porId;//ListaProductos
	private Detalle_Pedido detalle_pedidoSeleccionado;//Producto Seleccionado Editar
	private Long filtrarID;// Criterio de Busqueda
	
	//Pedido
	private Pedido pedido;//Para buscar el pedido que es del detalle que se esta creando
	private List<Pedido> listaPedidos;//Lista de Pedidos
	
	//Seria bueno una lista de pedidos mejor?
	//Al igual que una de productos, uhmm o un combo box que se busque por char por letra en el string de la palabra
	
	//Producto
	private Producto producto;//Para buscar el producto que es del detalle que se esta creando
	private List<Producto> listaProducto;//Lista de Producto
	
	//Descuento
	private Descuento descuento;//Para buscar el descuento que es del detalle que se esta creando
	private List<Descuento> listaDescuento;//Lista de Descuento
	
	
	

	@PostConstruct
	public void init() {
		detalle_pedido = new Detalle_Pedido();
		listaPedidos = new ArrayList<Pedido>();
		listaProducto = new ArrayList<Producto>();
		listaDescuento=new ArrayList<Descuento>();
		getTodosLosDetalles();
	}

	public void getTodosLosDetalles() {
		try {
			listaDetalle_Pedido= detalle_pedidoBusiness.getListaDetalle_Pedido();
		} catch (Exception e) {
			Message.messageError("Error Carga de Detalle del Pedido :" + e.getMessage());
		}
	}
	
	public void getTodosLosPedidos() {//para el combo box
		try {
			listaPedidos = pedidoBusiness.getListaPedidos();
		} catch (Exception e) {
			Message.messageError("Error Carga de Pedidos :" + e.getMessage());
		}
	}
//
	public void getTodosLosProductos() {//para el combo box
		try {
			listaProducto = productoBusiness.getListaProductos();
		} catch (Exception e) {
			Message.messageError("Error Carga de Producto :" + e.getMessage());
		}
	}
	
	public void getTodosLosDescuentos() {//para el combo box
		try {
			listaDescuento = descuentoBusiness.getListaDescuento();
		} catch (Exception e) {
			Message.messageError("Error Carga de Descuento :" + e.getMessage());
		}
	}
	
	
	

	
	public String nuevoDetallePedido() {
		resetForm();
		
		getTodosLosPedidos();
		getTodosLosProductos();
		getTodosLosDescuentos();
		
		return "insert.xhtml";//falta configurar
	}

	public String listaDetallePedido() {
		return "list.xhtml";//falta configurar
	}

	public String guardarDetallePedido() {
		String view = "";
		try {

			if (detalle_pedido.getId() != null) {
				detalle_pedido.setIdPedido(pedido);
				
				detalle_pedidoBusiness.editar(detalle_pedido);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				detalle_pedido.setIdPedido(pedido);
				
				detalle_pedidoBusiness.ingresar(detalle_pedido);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getTodosLosDetalles();
			resetForm();
			view = "list";
		} catch (Exception e) {
			Message.messageError("Error Detalle del Pedido :" + e.getStackTrace());
		}

		return view;
	}

	public String editarDetallePedido() {
		String view = "";
		try {
			if (this.detalle_pedidoSeleccionado != null) {
				this.detalle_pedido = detalle_pedidoSeleccionado;

				view = "update";// Vista
			} else {
				Message.messageInfo("Debe seleccionar un detalle pedido");
			}
		} catch (Exception e) {
			Message.messageError("Error Detalle del Pedido :" + e.getMessage());
		}

		return view;
	}

	public void buscarDetallePorId() {
		try {
			listaDetalle_Pedido_porId = detalle_pedidoBusiness.getDetalle_PedidoPorId(filtrarID);
			resetForm();
			if (listaDetalle_Pedido_porId.isPresent()) {
				Message.messageInfo("No se encontraron detalle");

			}

		} catch (Exception e) {
			Message.messageError("Error Detalle Pedido buscar :" + e.getMessage());
		}
	}

	public void selectProduct(SelectEvent e) {
		this.detalle_pedidoSeleccionado = (Detalle_Pedido) e.getObject();
	}

	public void resetForm() {
		this.filtrarID=null;
		this.detalle_pedido = new Detalle_Pedido();
	}
	
	
	
	
	
	
	public Detalle_Pedido getDetalle_pedido() {
		return detalle_pedido;
	}

	public void setDetalle_pedido(Detalle_Pedido detalle_pedido) {
		this.detalle_pedido = detalle_pedido;
	}

	public List<Detalle_Pedido> getListaDetalle_Pedido() {
		return listaDetalle_Pedido;
	}

	public void setListaDetalle_Pedido(List<Detalle_Pedido> listaDetalle_Pedido) {
		this.listaDetalle_Pedido = listaDetalle_Pedido;
	}

	public Optional<Detalle_Pedido> getListaDetalle_Pedido_porId() {
		return listaDetalle_Pedido_porId;
	}

	public void setListaDetalle_Pedido_porId(Optional<Detalle_Pedido> listaDetalle_Pedido_porId) {
		this.listaDetalle_Pedido_porId = listaDetalle_Pedido_porId;
	}

	public Detalle_Pedido getDetalle_pedidoSeleccionado() {
		return detalle_pedidoSeleccionado;
	}

	public void setDetalle_pedidoSeleccionado(Detalle_Pedido detalle_pedidoSeleccionado) {
		this.detalle_pedidoSeleccionado = detalle_pedidoSeleccionado;
	}

	public Long getFiltrarID() {
		return filtrarID;
	}

	public void setFiltrarID(Long filtrarID) {
		this.filtrarID = filtrarID;
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	public List<Pedido> getListaPedidos() {
		return listaPedidos;
	}

	public void setListaPedidos(List<Pedido> listaPedidos) {
		this.listaPedidos = listaPedidos;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public List<Producto> getListaProducto() {
		return listaProducto;
	}

	public void setListaProducto(List<Producto> listaProducto) {
		this.listaProducto = listaProducto;
	}

	public Descuento getDescuento() {
		return descuento;
	}

	public void setDescuento(Descuento descuento) {
		this.descuento = descuento;
	}

	public List<Descuento> getListaDescuento() {
		return listaDescuento;
	}

	public void setListaDescuento(List<Descuento> listaDescuento) {
		this.listaDescuento = listaDescuento;
	}

}
