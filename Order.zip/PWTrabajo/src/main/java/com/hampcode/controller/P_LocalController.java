package com.hampcode.controller;

import java.util.List;
import java.util.Optional;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.hampcode.business.DescuentoBusiness;
import com.hampcode.business.Detalle_PedidoBusiness;
import com.hampcode.business.PedidoBusiness;
import com.hampcode.business.ProductoBusiness;
import com.hampcode.model.entity.Detalle_Pedido;
import com.hampcode.model.entity.P_Local;

@Named
@SessionScoped
//Esto es mas q todo para el mozo
public class P_LocalController {
	@Inject
	private Detalle_PedidoBusiness detalle_pedidoBusiness;
	
	@Inject
	private PedidoBusiness pedidoBusiness;
	
	@Inject
	private ProductoBusiness productoBusiness;
	
	@Inject
	private DescuentoBusiness descuentoBusiness;

	private P_Local p_local; //NuevoProducto
	private List<P_Local> listaP_Local;//ListaProductos
	private Optional<P_Local> listaP_Local_porId;//ListaProductos
	private P_Local p_localSeleccionado;//Producto Seleccionado Editar
	private Long filtrarID;// Criterio de Busqueda
	
	
	
}
