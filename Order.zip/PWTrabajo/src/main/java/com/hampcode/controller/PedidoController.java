package com.hampcode.controller;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.hampcode.business.DescuentoBusiness;
import com.hampcode.business.Detalle_PedidoBusiness;
import com.hampcode.business.P_LocalBusiness;
import com.hampcode.business.PedidoBusiness;
import com.hampcode.business.ProductoBusiness;
import com.hampcode.model.entity.Descuento;
import com.hampcode.model.entity.Detalle_Pedido;
import com.hampcode.model.entity.Pedido;
import com.hampcode.model.entity.Producto;
//La mayor parte de las funciones van a ser usadas por el cajero
@Named
@SessionScoped
public class PedidoController implements Serializable{

	private static final long serialVersionUID = 1L;

	@Inject
	private PedidoBusiness pedidoBusiness;
	
	@Inject
	private P_LocalBusiness p_localBusiness;
	
	@Inject
	private DescuentoBusiness descuentoBusiness;
	
	private Detalle_Pedido detalle_pedido; //NuevoProducto
	private List<Detalle_Pedido> listaDetalle_Pedido;//ListaProductos
	private Optional<Detalle_Pedido> listaDetalle_Pedido_porId;//ListaProductos
	private Detalle_Pedido detalle_pedidoSeleccionado;//Producto Seleccionado Editar
	private Long filtrarID;// Criterio de Busqueda
	
	//Pedido
	private Pedido pedido;//Para buscar el pedido que es del detalle que se esta creando
	private List<Pedido> listaPedidos;//Lista de Pedidos
	
	//Seria bueno una lista de pedidos mejor?
	//Al igual que una de productos, uhmm o un combo box que se busque por char por letra en el string de la palabra
	
	//Producto
	private Producto producto;//Para buscar el producto que es del detalle que se esta creando
	private List<Producto> listaProducto;//Lista de Producto
	
	//Descuento
	private Descuento descuento;//Para buscar el descuento que es del detalle que se esta creando
	private List<Descuento> listaDescuento;//Lista de Descuento
	
	
}
