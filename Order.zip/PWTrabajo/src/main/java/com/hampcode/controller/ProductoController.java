package com.hampcode.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import com.hampcode.business.ProductoBusiness;
import com.hampcode.model.entity.Producto;
import com.hampcode.util.Message;

@Named
@SessionScoped
public class ProductoController implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private ProductoBusiness productBusiness;

	//@Inject
	//private SupplierBusiness supplierBusiness;

	private Producto product; //NuevoProducto
	private List<Producto> products;//ListaProductos
	private Producto productSelect;//Producto Seleccionado Editar
	private String filterName;// Criterio de Busqueda
	
	//Supplier
	//private Supplier supplier;
	//private List<Supplier> suppliers;//ListaProductos
	
	
	@PostConstruct
	public void init() {
		product = new Producto();
		products = new ArrayList<Producto>();
		//suppliers=new ArrayList<Supplier>();
		getAllProducts();
	}

	public void getAllProducts() {
		try {
			products = productBusiness.getListaProductos();
		} catch (Exception e) {
			Message.messageError("Error Carga de Productos :" + e.getMessage());
		}
	}

	//public void getAllSuppliers() {
	//	try {
	//		suppliers = supplierBusiness.getAll();
	//	} catch (Exception e) {
	//		Message.messageError("Error Carga de Proveedores :" + e.getMessage());
	//	}
	//}
	

	
	public String newProduct() {
		resetForm();
		//getAllSuppliers();
		return "insert.xhtml";//Corregir el xhtml
	}

	public String listProduct() {
		return "list.xhtml";//Corregir el xhtml
	}

	public String saveProduct() {
		String view = "";
		try {

			if (product.getId() != null) {
				//product.setSupplier(supplier);
				
				productBusiness.editar(product);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				//product.setSupplier(supplier);
				
				productBusiness.ingresar(product);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getAllProducts();
			resetForm();
			view = "list";
		} catch (Exception e) {
			Message.messageError("Error Product :" + e.getStackTrace());
		}

		return view;
	}

	public String editProduct() {
		String view = "";
		try {
			if (this.productSelect != null) {
				this.product = productSelect;

				view = "update";// Vista
			} else {
				Message.messageInfo("Debe seleccionar un producto");
			}
		} catch (Exception e) {
			Message.messageError("Error Product :" + e.getMessage());
		}

		return view;
	}

	public void searchProductByName() {
		try {

			products = productBusiness.getProductoPorNombre(this.filterName.trim());
			resetForm();
			if (products.isEmpty()) {
				Message.messageInfo("No se encontraron productos");

			}

		} catch (Exception e) {
			Message.messageError("Error Product Search :" + e.getMessage());
		}
	}

	public void selectProduct(SelectEvent e) {
		this.productSelect = (Producto) e.getObject();
	}

	public void resetForm() {
		this.filterName="";
		this.product = new Producto();
	}

	
	
	
	
	/*
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Product getProductSelect() {
		return productSelect;
	}

	public void setProductSelect(Product productSelect) {
		this.productSelect = productSelect;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public List<Supplier> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<Supplier> suppliers) {
		this.suppliers = suppliers;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	
	*/
}
