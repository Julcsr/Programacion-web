package com.hampcode.model.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.hampcode.model.entity.Pedido;
import com.hampcode.model.entity.Sucursal;
//MOZO
@Named
public class PedidoRepository implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName="pwPU")
	private EntityManager em;
	
	public Long insertar(Pedido pedido)throws Exception {
		em.persist(pedido);
		return pedido.getId();
	}
	
	public Long editar(Pedido pedido) throws Exception {
		em.merge(pedido);
		return pedido.getId();
	}
	
	
	public void eliminar(Pedido pedido) throws Exception {
		em.remove(pedido);
	}
	
	public List<Pedido> listaPedido() throws Exception{
		List<Pedido> pedido=new ArrayList<>();
		
		TypedQuery<Pedido> query=em.createQuery("FROM Pedido pe",Pedido.class);
		pedido=query.getResultList();
		
		return pedido;
	}
	
	public Optional<Pedido> encontrarPedidoPorId(Long idPedido) throws Exception{
		Pedido pedidoEncontrado;
		
		TypedQuery<Pedido> query=em.createQuery("FROM Pedido pe WHERE pe.id=?1",Pedido.class);
		
		query.setParameter(1, idPedido);
		pedidoEncontrado=query.getSingleResult();
		
		return Optional.of(pedidoEncontrado);
	}
	
	public List<Sucursal> encontrarPorNombreSucursal(String nombrePedido) throws Exception{
		List<Sucursal> sucursales=new ArrayList<>();
		
		TypedQuery<Sucursal> query=em.createQuery("FROM Sucursal su WHERE su.name LIKE ?1" ,Sucursal.class);
		query.setParameter(1, "%"+nombrePedido+"%");
		sucursales=query.getResultList();
		
		return sucursales;
	}
	
	//No hay la posibilidad de un buscar por local, ya que eso depende de P_Local
	/*
	public Optional<Pedido> encontrarPedidoPorIdLocal(Long idLocal) throws Exception{
		Pedido pedidoEncontrado;
		
		TypedQuery<Pedido> query=em.createQuery("FROM Pedido pe WHERE pe.id=?1",Pedido.class);
		
		query.setParameter(1, idPedido);
		pedidoEncontrado=query.getSingleResult();
		
		return Optional.of(pedidoEncontrado);
	}*/
	
}
