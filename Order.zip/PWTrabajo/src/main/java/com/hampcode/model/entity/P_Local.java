package com.hampcode.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//Este va a ser el formulario del mozo :v, ya que tiene la meza, el mozo y el pedido

@Entity
@Table(name="Local")
public class P_Local {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Long id;
	
	@ManyToOne
	@JoinColumn(name="mesaId", nullable=false)
	Mesa idMesa;
	
	//@ManyToOne
	//@JoinColumn(name="mesaId", nullable=false)
	//Mesa idMesa;
	
	@ManyToOne
	@JoinColumn(name="empleadoId", nullable=false)
	Empleado idEmpleado;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Mesa getIdMesa() {
		return idMesa;
	}

	public void setIdMesa(Mesa idMesa) {
		this.idMesa = idMesa;
	}

	public Empleado getIdEmpleado() {
		return idEmpleado;
	}

	public void setIdEmpleado(Empleado idEmpleado) {
		this.idEmpleado = idEmpleado;
	}
	
	
	
	
}
