package com.hampcode.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Orden_Insumo")

public class Orden_Insumo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="orden_compraId")
	private Orden_Compra idOrden_Compra;

	
	@ManyToOne
	@JoinColumn(name="insumoId")
	private Insumo idInsumo;
	
	@Column(name = "costo", nullable = false)
	private double costo;
//
	@Column(name = "cantidadInsumos", nullable = false)
	private int cantidadInsumos;
//	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Orden_Compra getIdOrden_Compra() {
		return idOrden_Compra;
	}

	public void setIdOrden_Compra(Orden_Compra idOrden_Compra) {
		this.idOrden_Compra = idOrden_Compra;
	}
	public Insumo getIdInsumo() {
		return idInsumo;
	}
	public void setIdInsumo(Insumo idInsumo) {
		this.idInsumo = idInsumo;
	}
	public double getCosto() {
		return costo;
	}
	public void setCosto(double costo) {
		this.costo = costo;
	}
	public int getCantidadInsumos() {
		return cantidadInsumos;
	}
	public void setCantidadInsumos(int cantidadInsumos) {
		this.cantidadInsumos = cantidadInsumos;
	}

	

	
}
