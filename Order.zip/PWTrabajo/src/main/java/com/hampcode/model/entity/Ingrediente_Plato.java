package com.hampcode.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ingrediente_Plato")

public class Ingrediente_Plato {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="insumoId")
	private Insumo idInsumo;

	@ManyToOne
	@JoinColumn(name="productoId")
	private Producto idProducto;
	
	@ManyToOne
	@JoinColumn(name="unidadId")
	private Unidad idUnidad;

	@Column(name="cantidad", nullable=false, length=50)
	private String cantidad;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Insumo getIdInsumo() {
		return idInsumo;
	}

	public void setIdInsumo(Insumo idInsumo) {
		this.idInsumo = idInsumo;
	}

	public Producto getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Producto idProducto) {
		this.idProducto = idProducto;
	}

	public Unidad getIdUnidad() {
		return idUnidad;
	}

	public void setIdUnidad(Unidad idUnidad) {
		this.idUnidad = idUnidad;
	}

	public String getCantidad() {
		return cantidad;
	}

	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}

	
}
