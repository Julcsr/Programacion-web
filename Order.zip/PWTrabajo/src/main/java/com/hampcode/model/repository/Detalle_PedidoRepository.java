package com.hampcode.model.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.hampcode.model.entity.Detalle_Pedido;
//CAJERO
@Named
public class Detalle_PedidoRepository implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName="pwPU")
	private EntityManager em;
	
	public Long insertar(Detalle_Pedido detalle_pedido)throws Exception {
		em.persist(detalle_pedido);
		return detalle_pedido.getId();
	}
	
	public Long editar(Detalle_Pedido detalle_pedido) throws Exception {
		em.merge(detalle_pedido);
		return detalle_pedido.getId();
	}
	
	
	public void eliminar(Detalle_Pedido detalle_pedido) throws Exception {
		em.remove(detalle_pedido);
	}

	public List<Detalle_Pedido> listaDetalle_Pedido() throws Exception{
		List<Detalle_Pedido> detalle_pedido=new ArrayList<>();
		
		TypedQuery<Detalle_Pedido> query=em.createQuery("FROM Detalle_Pedido dp"
				,Detalle_Pedido.class);
		detalle_pedido=query.getResultList();
		
		return detalle_pedido;
	}
	
	public Optional<Detalle_Pedido> encontrarDetalle_PedidoPorId(Long idDetalle_Pedido) throws Exception{
		Detalle_Pedido detalle_pedidoEncontrado;
		
		TypedQuery<Detalle_Pedido> query=em.createQuery("FROM Detalle_Pedido dp WHERE dp.id=?1"
				,Detalle_Pedido.class);
		
		
		
		query.setParameter(1, idDetalle_Pedido);
		detalle_pedidoEncontrado=query.getSingleResult();
		
		return Optional.of(detalle_pedidoEncontrado);
	}
	
}
