package com.hampcode.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Descuento")
public class Descuento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="perDescuento", nullable=false)
	private double perDescuento;

	
	//FALTA FECHA INICIO
	
	//FALTA FECHA FIN
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getPerDescuento() {
		return perDescuento;
	}

	public void setPerDescuento(double perDescuento) {
		this.perDescuento = perDescuento;
	}
	

}
