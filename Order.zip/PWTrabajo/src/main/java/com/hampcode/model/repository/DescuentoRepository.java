package com.hampcode.model.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.hampcode.model.entity.Descuento;

@Named
public class DescuentoRepository implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName="pwPU")
	private EntityManager em;
	
	public Long insertar(Descuento descuento)throws Exception {
		em.persist(descuento);
		return descuento.getId();
	}
	
	public Long editar(Descuento descuento) throws Exception {
		em.merge(descuento);
		return descuento.getId();
	}
	
	
	public void eliminar(Descuento descuento) throws Exception {
		em.remove(descuento);
	}

	public List<Descuento> listaDescuento() throws Exception{
		List<Descuento> descuento=new ArrayList<>();
		
		TypedQuery<Descuento> query=em.createQuery("FROM Descuento des" ,Descuento.class);
		descuento=query.getResultList();
		
		return descuento;
	}
	
	public Optional<Descuento> encontrarDescuentoPorId(Long idDescuento) throws Exception{
		Descuento descuentoEncontrado;
		
		TypedQuery<Descuento> query=em.createQuery("FROM Descuento des WHERE des.id=?1",Descuento.class);
		
		
		
		query.setParameter(1, idDescuento);
		descuentoEncontrado=query.getSingleResult();
		
		return Optional.of(descuentoEncontrado);
	}
	
}
