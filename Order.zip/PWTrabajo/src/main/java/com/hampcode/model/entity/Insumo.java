package com.hampcode.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Insumo")

public class Insumo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name="saborId")
	private Sabor idSabor;

	@ManyToOne
	@JoinColumn(name="marcaId")
	private Marca idMarca;

	@ManyToOne
	@JoinColumn(name="unidadId")
	private Unidad idUnidad;
	
	@Column(name = "nombre", nullable = false)
	private String nombre;

	@Column(name = "cantidad", nullable = true)
	private int cantidad;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Sabor getIdSabor() {
		return idSabor;
	}

	public void setIdSabor(Sabor idSabor) {
		this.idSabor = idSabor;
	}

	public Marca getIdMarca() {
		return idMarca;
	}

	public void setIdMarca(Marca idMarca) {
		this.idMarca = idMarca;
	}

	public Unidad getIdUnidad() {
		return idUnidad;
	}

	public void setIdUnidad(Unidad idUnidad) {
		this.idUnidad = idUnidad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	
	
	
	
}
