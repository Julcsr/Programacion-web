package com.hampcode.model.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.hampcode.model.entity.Producto;

public class ProductoRepository implements Serializable{

	private static final long serialVersionUID = 1L;	
	
	@PersistenceContext(unitName="pwPU")
	private EntityManager em;
	
	public Long ingresar(Producto producto_) throws Exception {
		em.persist(producto_);
		return producto_.getId();
	}
	
	
	public Long editar(Producto producto_) throws Exception {
		em.merge(producto_);
		return producto_.getId();
	}
	
	
	public void eliminar(Producto producto_) throws Exception {
		em.remove(producto_);
	}
	
	
	public List<Producto> listaProductos() throws Exception{
		List<Producto> products=new ArrayList<>();
		
		TypedQuery<Producto> query=em.createQuery("FROM Producto p"
				,Producto.class);
		products=query.getResultList();
		
		return products;
	}
	
	
	public Optional<Producto> encontrarProductoPorId(Long idProducto_) throws Exception{
		Producto productoEncontrado;
		
		TypedQuery<Producto> query=em.createQuery("FROM Product p WHERE p.id=?1"
				,Producto.class);
		
		
		
		query.setParameter(1, idProducto_);
		productoEncontrado=query.getSingleResult();
		
		return Optional.of(productoEncontrado);
	}
	
	
	public List<Producto> encontrarPorNombre(String nombreProducto_) throws Exception{
		List<Producto> productos=new ArrayList<>();
		
		TypedQuery<Producto> query=em.createQuery("FROM Product p WHERE p.name LIKE ?1"
				,Producto.class);
		query.setParameter(1, "%"+nombreProducto_+"%");
		productos=query.getResultList();
		
		return productos;
	}
	
}
