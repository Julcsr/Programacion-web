package com.hampcode.model.repository;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.hampcode.model.entity.P_Local;

public class P_LocalRepository implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName="pwPU")
	private EntityManager em;
	
	public Long insertar(P_Local p_Local)throws Exception {
		em.persist(p_Local);
		return p_Local.getId();
	}
	

}
