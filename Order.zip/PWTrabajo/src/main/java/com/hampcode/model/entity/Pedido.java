package com.hampcode.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Pedido")
public class Pedido {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="sucursalId")
	private Sucursal idSucursal;
	
	@ManyToOne
	@JoinColumn(name="tipo_pedidoId")
	private Tipo_Pedido idTipo_Pedido;

	
	//FALTA FECHA PEDIDO
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Sucursal getIdSucursal() {
		return idSucursal;
	}

	public void setIdSucursal(Sucursal idSucursal) {
		this.idSucursal = idSucursal;
	}

	public Tipo_Pedido getIdTipo_Pedido() {
		return idTipo_Pedido;
	}

	public void setIdTipo_Pedido(Tipo_Pedido idTipo_Pedido) {
		this.idTipo_Pedido = idTipo_Pedido;
	}

	

}
