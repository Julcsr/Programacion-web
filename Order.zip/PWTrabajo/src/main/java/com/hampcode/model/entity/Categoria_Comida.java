package com.hampcode.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Orden_Insumo")

public class Categoria_Comida {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="nombre", nullable=false, length=50)
	private String nombre;
	
	@Column(name="categoria", nullable=true)
	private Categoria_Comida categoria;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Categoria_Comida getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria_Comida categoria) {
		this.categoria = categoria;
	}

	
	
}
