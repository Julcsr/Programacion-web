package com.hampcode.business;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import com.hampcode.model.entity.Producto;
import com.hampcode.model.repository.ProductoRepository;

@Named
public class ProductoBusiness implements Serializable{

	private static final long serialVersionUID = 1L;

	@Inject
	private ProductoRepository productRepository;

	@Transactional 
	public Long ingresar(Producto producto_) throws Exception {
		return productRepository.ingresar(producto_);
	}

	@Transactional
	public Long editar(Producto producto_) throws Exception{
		return productRepository.editar(producto_);
	}
	
	
	public List<Producto> getListaProductos() throws Exception {
		return productRepository.listaProductos();
	}
	
	
	public List<Producto> getProductoPorNombre(String nombreProducto_) throws Exception{
		return productRepository.encontrarPorNombre(nombreProducto_);
	}
	
}
