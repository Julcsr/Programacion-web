package com.hampcode.business;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.transaction.Transactional;

import com.hampcode.model.entity.Descuento;
import com.hampcode.model.repository.DescuentoRepository;

public class DescuentoBusiness implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Inject
	private DescuentoRepository descuentoRepository;
	
	@Transactional 
	public Long ingresar(Descuento descuento) throws Exception {
		return descuentoRepository.insertar(descuento);
	}
	
	@Transactional
	public Long editar(Descuento descuento) throws Exception{
		return descuentoRepository.editar(descuento);
	}
	
	
	public List<Descuento> getListaDescuento() throws Exception {
		return descuentoRepository.listaDescuento();
	}
	
	
	public Optional<Descuento> getDescuentoPorId(Long idDescuento) throws Exception{
		return descuentoRepository.encontrarDescuentoPorId(idDescuento);
	}
}
