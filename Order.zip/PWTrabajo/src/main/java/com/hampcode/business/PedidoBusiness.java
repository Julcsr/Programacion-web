package com.hampcode.business;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.transaction.Transactional;

import com.hampcode.model.entity.Pedido;
import com.hampcode.model.entity.Producto;


public class PedidoBusiness {
	@Inject
	private PedidoBusiness pedidoRepository;

	@Transactional 
	public Long ingresar(Pedido pedido) throws Exception {
		return pedidoRepository.ingresar(pedido);
	}

	@Transactional
	public Long editar(Producto producto_) throws Exception{
		return pedidoRepository.editar(producto_);
	}
	
	
	public List<Pedido> getListaPedidos() throws Exception {
		return pedidoRepository.getListaPedidos();
	}
	
	
	public Optional<Pedido> getPedidoPorId(Long idPedido) throws Exception{
		return pedidoRepository.getPedidoPorId(idPedido);
	}
	
}
