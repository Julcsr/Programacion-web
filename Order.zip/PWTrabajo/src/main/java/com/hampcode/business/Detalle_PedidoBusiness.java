package com.hampcode.business;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import com.hampcode.model.entity.Detalle_Pedido;
import com.hampcode.model.repository.Detalle_PedidoRepository;

@Named
public class Detalle_PedidoBusiness implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	private Detalle_PedidoRepository detalle_pedidoRepository;
	
	@Transactional 
	public Long ingresar(Detalle_Pedido detalle_pedido) throws Exception {
		return detalle_pedidoRepository.insertar(detalle_pedido);
	}
	
	@Transactional
	public Long editar(Detalle_Pedido detalle_pedido) throws Exception{
		return detalle_pedidoRepository.editar(detalle_pedido);
	}
	
	
	public List<Detalle_Pedido> getListaDetalle_Pedido() throws Exception {
		return detalle_pedidoRepository.listaDetalle_Pedido();
	}
	
	
	public Optional<Detalle_Pedido> getDetalle_PedidoPorId(Long idDetalle_Pedido) throws Exception{
		return detalle_pedidoRepository.encontrarDetalle_PedidoPorId(idDetalle_Pedido);
	}

}
