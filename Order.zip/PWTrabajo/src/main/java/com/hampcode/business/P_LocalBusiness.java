package com.hampcode.business;

import java.io.Serializable;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import com.hampcode.model.entity.P_Local;
import com.hampcode.model.repository.P_LocalRepository;

@Named
public class P_LocalBusiness implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Inject
	private P_LocalRepository p_localRepository;
	
	@Transactional 
	public Long ingresar(P_Local p_local) throws Exception {
		return p_localRepository.insertar(p_local);
	}
}
