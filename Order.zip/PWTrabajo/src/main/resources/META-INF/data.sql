INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product1', 1, 2, 18.00, 10);
INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product2', 1, 2, 19.00, 40);
INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product3',2, 1, 20.00, 10);
INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product4', 2, 2, 30.00, 20);
INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product5', 3, 1, 20.00, 30);
INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product6', 3, 2, 15.00, 17);
INSERT INTO products (name,supplier,category,unit_price,units_in_stock) VALUES ('Product7', 3, 2, 20.00, 17);


