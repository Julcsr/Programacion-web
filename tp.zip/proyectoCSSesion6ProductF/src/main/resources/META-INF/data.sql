  
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor1', 984531123, 'av Industrial 125');
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor2',  984531723, 'av Industrial 25');
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor3', 984531123, 'av Industrial 129');
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor4',  994531123, 'av Industrial 122');
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor5',  984531723, 'av Industrial 128');
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor6',  984531123, 'av Industrial 153');
INSERT INTO proveedor(nproveedor,numtelefono_proveedor,tdireccion_proveedor ) VALUES ('Proveedor7', 984531133, 'av Industrial 157');

INSERT INTO marcas(nombre_marca) VALUES ('Coca Cola');
INSERT INTO marcas(nombre_marca) VALUES ('Inka Kola');
INSERT INTO marcas(nombre_marca) VALUES ('Kola Real');
INSERT INTO marcas(nombre_marca) VALUES ('Pepsi');
INSERT INTO marcas(nombre_marca) VALUES ('Sprite');

INSERT INTO sabores(nombre_sabor) VALUES ('Naranja');
INSERT INTO sabores(nombre_sabor) VALUES ('Limon');
INSERT INTO sabores(nombre_sabor) VALUES ('Cola Amarilla');
INSERT INTO sabores(nombre_sabor) VALUES ('Cola');

INSERT INTO unidades(nombre_unidad) VALUES ('Litro');
INSERT INTO unidades(nombre_unidad) VALUES ('Mililitro');
INSERT INTO unidades(nombre_unidad) VALUES ('Gramo');
INSERT INTO unidades(nombre_unidad) VALUES ('Kilogramo');

INSERT INTO cargos(nombre_cargo) VALUES ('Cocinero');
INSERT INTO cargos(nombre_cargo) VALUES ('Motorizado');
INSERT INTO cargos(nombre_cargo) VALUES ('Recepcionista de llamadas');
INSERT INTO cargos(nombre_cargo) VALUES ('Mozo');

INSERT INTO tipos_pedidos(nombre_tipos) VALUES ('Comer aqu�');
INSERT INTO tipos_pedidos(nombre_tipos) VALUES ('Para llevar');
INSERT INTO tipos_pedidos(nombre_tipos) VALUES ('Delivery');

INSERT INTO sucursales(numero_telefono, direccion) VALUES (988574951, 'Enrique Segoviano, Santa Anita');
INSERT INTO sucursales(numero_telefono, direccion) VALUES (980975451, 'Calle Nueva, Vitarte');

