package com.hampcode.model.entity;

public class Nothing {

}
