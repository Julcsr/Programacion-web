package com.hampcode.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="ordenes_compras")
public class OrdenCompra {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Long idOrdenCompra;
	@ManyToMany
	@JoinColumn(name="id_proveedor")
	Supplier proveedor;
	@ManyToMany
	@JoinColumn(name="id_sucursal")
	Sucursal sucursal;

	
}
