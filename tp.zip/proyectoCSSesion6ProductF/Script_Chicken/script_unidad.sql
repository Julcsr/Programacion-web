INSERT INTO public.unidades(
	nombre_unidad)
	VALUES ('gramos');
INSERT INTO public.unidades(
	nombre_unidad)
	VALUES ('kilogramo');
INSERT INTO public.unidades(
	nombre_unidad)
	VALUES ('litro');
INSERT INTO public.unidades(
	nombre_unidad)
	VALUES ('mililitro');