INSERT INTO public.insumos(
	id_marca, nombre_insumo, porcion, id_sabor, id_unidad)
	VALUES ('1', '1', 1, '1', '1');