package com.hampcode.model.entity;

public class TipoPedido {
	Long idTipoPedido;
	String nombreTipoPedido;

	public Long getIdTipoPedido() {
		return idTipoPedido;
	}

	public void setIdTipoPedido(Long idTipoPedido) {
		this.idTipoPedido = idTipoPedido;
	}

	public String getNombreTipoPedido() {
		return nombreTipoPedido;
	}

	public void setNombreTipoPedido(String nombreTipoPedido) {
		this.nombreTipoPedido = nombreTipoPedido;
	}

}
