package com.hampcode.model.entity;

@Entity
@Table(name = "pais")
public class Pais {
	Long idPais;
	String nombrePais;

	public Long getIdPais() {
		return idPais;
	}

	public void setIdPais(Long idPais) {
		this.idPais = idPais;
	}

	public String getNombrePais() {
		return nombrePais;
	}

	public void setNombrePais(String nombrePais) {
		this.nombrePais = nombrePais;
	}

}
